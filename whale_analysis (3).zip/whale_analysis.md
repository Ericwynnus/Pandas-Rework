 #  A Whale off the Port(folio)
 ---

 In this assignment, you'll get to use what you've learned this week to evaluate the performance among various algorithmic, hedge, and mutual fund portfolios and compare them against the S&P 500 Index.


```python
# Initial imports
import pandas as pd
import numpy as np
import datetime as dt
from pathlib import Path

%matplotlib inline
```

    
    Bad key text.latex.preview in file C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\matplotlib\mpl-data\stylelib\_classic_test.mplstyle, line 123 ('text.latex.preview : False')
    You probably need to get an updated matplotlibrc file from
    https://github.com/matplotlib/matplotlib/blob/v3.5.1/matplotlibrc.template
    or from the matplotlib source distribution
    
    Bad key mathtext.fallback_to_cm in file C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\matplotlib\mpl-data\stylelib\_classic_test.mplstyle, line 155 ('mathtext.fallback_to_cm : True  # When True, use symbols from the Computer Modern')
    You probably need to get an updated matplotlibrc file from
    https://github.com/matplotlib/matplotlib/blob/v3.5.1/matplotlibrc.template
    or from the matplotlib source distribution
    
    Bad key savefig.jpeg_quality in file C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\matplotlib\mpl-data\stylelib\_classic_test.mplstyle, line 418 ('savefig.jpeg_quality: 95       # when a jpeg is saved, the default quality parameter.')
    You probably need to get an updated matplotlibrc file from
    https://github.com/matplotlib/matplotlib/blob/v3.5.1/matplotlibrc.template
    or from the matplotlib source distribution
    
    Bad key savefig.frameon in file C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\matplotlib\mpl-data\stylelib\_classic_test.mplstyle, line 421 ('savefig.frameon : True')
    You probably need to get an updated matplotlibrc file from
    https://github.com/matplotlib/matplotlib/blob/v3.5.1/matplotlibrc.template
    or from the matplotlib source distribution
    
    Bad key verbose.level in file C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\matplotlib\mpl-data\stylelib\_classic_test.mplstyle, line 472 ('verbose.level  : silent      # one of silent, helpful, debug, debug-annoying')
    You probably need to get an updated matplotlibrc file from
    https://github.com/matplotlib/matplotlib/blob/v3.5.1/matplotlibrc.template
    or from the matplotlib source distribution
    
    Bad key verbose.fileo in file C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\matplotlib\mpl-data\stylelib\_classic_test.mplstyle, line 473 ('verbose.fileo  : sys.stdout  # a log filename, sys.stdout or sys.stderr')
    You probably need to get an updated matplotlibrc file from
    https://github.com/matplotlib/matplotlib/blob/v3.5.1/matplotlibrc.template
    or from the matplotlib source distribution
    
    Bad key keymap.all_axes in file C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\matplotlib\mpl-data\stylelib\_classic_test.mplstyle, line 490 ('keymap.all_axes : a                 # enable all axes')
    You probably need to get an updated matplotlibrc file from
    https://github.com/matplotlib/matplotlib/blob/v3.5.1/matplotlibrc.template
    or from the matplotlib source distribution
    
    Bad key animation.avconv_path in file C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\matplotlib\mpl-data\stylelib\_classic_test.mplstyle, line 501 ('animation.avconv_path: avconv     # Path to avconv binary. Without full path')
    You probably need to get an updated matplotlibrc file from
    https://github.com/matplotlib/matplotlib/blob/v3.5.1/matplotlibrc.template
    or from the matplotlib source distribution
    
    Bad key animation.avconv_args in file C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\matplotlib\mpl-data\stylelib\_classic_test.mplstyle, line 503 ('animation.avconv_args:            # Additional arguments to pass to avconv')
    You probably need to get an updated matplotlibrc file from
    https://github.com/matplotlib/matplotlib/blob/v3.5.1/matplotlibrc.template
    or from the matplotlib source distribution
    

# Data Cleaning

In this section, you will need to read the CSV files into DataFrames and perform any necessary data cleaning steps. After cleaning, combine all DataFrames into a single DataFrame.

Files:

* `whale_returns.csv`: Contains returns of some famous "whale" investors' portfolios.

* `algo_returns.csv`: Contains returns from the in-house trading algorithms from Harold's company.

* `sp500_history.csv`: Contains historical closing prices of the S&P 500 Index.

## Whale Returns

Read the Whale Portfolio daily returns and clean the data


```python
# Reading whale returns
csvpath = Path("Resources/whale_returns.csv")
csvpath
```




    WindowsPath('Resources/whale_returns.csv')




```python
whale_dataframe = pd.read_csv(
    csvpath, index_col="Date", infer_datetime_format=True, parse_dates=True)
whale_dataframe = whale_dataframe.sort_index()
whale_dataframe.head()



#algo_dataframe = Path("Resources/algo_returns.csv")
#algo_dataframe
#algo_dataframe = pd.read_csv(
#    algo_dataframe, index_col="Date", infer_datetime_format=True, parse_dates=True)
#algo_dataframe = algo_dataframe.sort_index()
#algo_dataframe.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-03-02</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2015-03-03</th>
      <td>-0.001266</td>
      <td>-0.004981</td>
      <td>-0.000496</td>
      <td>-0.006569</td>
    </tr>
    <tr>
      <th>2015-03-04</th>
      <td>0.002230</td>
      <td>0.003241</td>
      <td>-0.002534</td>
      <td>0.004213</td>
    </tr>
    <tr>
      <th>2015-03-05</th>
      <td>0.004016</td>
      <td>0.004076</td>
      <td>0.002355</td>
      <td>0.006726</td>
    </tr>
    <tr>
      <th>2015-03-06</th>
      <td>-0.007905</td>
      <td>-0.003574</td>
      <td>-0.008481</td>
      <td>-0.013098</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Count nulls
whale_dataframe.isnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1055</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1056</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1057</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1058</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1059</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>1060 rows × 5 columns</p>
</div>




```python
# Drop nulls
whale_dataframe.dropna(inplace=True)
whale_dataframe
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2015-03-03</td>
      <td>-0.001266</td>
      <td>-0.004981</td>
      <td>-0.000496</td>
      <td>-0.006569</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2015-03-04</td>
      <td>0.002230</td>
      <td>0.003241</td>
      <td>-0.002534</td>
      <td>0.004213</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2015-03-05</td>
      <td>0.004016</td>
      <td>0.004076</td>
      <td>0.002355</td>
      <td>0.006726</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2015-03-06</td>
      <td>-0.007905</td>
      <td>-0.003574</td>
      <td>-0.008481</td>
      <td>-0.013098</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2015-03-09</td>
      <td>0.000582</td>
      <td>0.004225</td>
      <td>0.005843</td>
      <td>-0.001652</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1055</th>
      <td>2019-04-25</td>
      <td>-0.000285</td>
      <td>-0.001291</td>
      <td>-0.005153</td>
      <td>0.004848</td>
    </tr>
    <tr>
      <th>1056</th>
      <td>2019-04-26</td>
      <td>0.008149</td>
      <td>0.009162</td>
      <td>0.012355</td>
      <td>0.010434</td>
    </tr>
    <tr>
      <th>1057</th>
      <td>2019-04-29</td>
      <td>0.001254</td>
      <td>0.002719</td>
      <td>0.006251</td>
      <td>0.005223</td>
    </tr>
    <tr>
      <th>1058</th>
      <td>2019-04-30</td>
      <td>-0.001295</td>
      <td>-0.002211</td>
      <td>-0.000259</td>
      <td>-0.003702</td>
    </tr>
    <tr>
      <th>1059</th>
      <td>2019-05-01</td>
      <td>-0.005847</td>
      <td>-0.001341</td>
      <td>-0.007936</td>
      <td>-0.007833</td>
    </tr>
  </tbody>
</table>
<p>1059 rows × 5 columns</p>
</div>



## Algorithmic Daily Returns

Read the algorithmic daily returns and clean the data


```python
# Reading algorithmic returns
algo_dataframe = Path("Resources/algo_returns.csv")
algo_dataframe


```




    WindowsPath('Resources/algo_returns.csv')




```python
#algo_dataframe = pd.read_csv(algo_dataframe)
#algo_dataframe.head()

algo_dataframe = pd.read_csv(
    algo_dataframe, index_col="Date", infer_datetime_format=True, parse_dates=True)
algo_dataframe = algo_dataframe.sort_index()
algo_dataframe.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Algo 1</th>
      <th>Algo 2</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2014-05-28</th>
      <td>0.001745</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2014-05-29</th>
      <td>0.003978</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2014-05-30</th>
      <td>0.004464</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2014-06-02</th>
      <td>0.005692</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2014-06-03</th>
      <td>0.005292</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Count nulls
algo_dataframe.isnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Algo 1</th>
      <th>Algo 2</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2014-05-28</th>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2014-05-29</th>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2014-05-30</th>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2014-06-02</th>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2014-06-03</th>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2019-04-25</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2019-04-26</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2019-04-29</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2019-04-30</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2019-05-01</th>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>1241 rows × 2 columns</p>
</div>




```python
# Drop nulls
algo_dataframe.dropna(inplace=True)
algo_dataframe
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Algo 1</th>
      <th>Algo 2</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2014-06-05</th>
      <td>0.004062</td>
      <td>0.013285</td>
    </tr>
    <tr>
      <th>2014-06-06</th>
      <td>0.001857</td>
      <td>0.008284</td>
    </tr>
    <tr>
      <th>2014-06-09</th>
      <td>-0.005012</td>
      <td>0.005668</td>
    </tr>
    <tr>
      <th>2014-06-10</th>
      <td>0.004406</td>
      <td>-0.000735</td>
    </tr>
    <tr>
      <th>2014-06-11</th>
      <td>0.004760</td>
      <td>-0.003761</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2019-04-25</th>
      <td>0.000682</td>
      <td>-0.007247</td>
    </tr>
    <tr>
      <th>2019-04-26</th>
      <td>0.002981</td>
      <td>0.005256</td>
    </tr>
    <tr>
      <th>2019-04-29</th>
      <td>0.005208</td>
      <td>0.002829</td>
    </tr>
    <tr>
      <th>2019-04-30</th>
      <td>-0.002944</td>
      <td>-0.001570</td>
    </tr>
    <tr>
      <th>2019-05-01</th>
      <td>0.000094</td>
      <td>-0.007358</td>
    </tr>
  </tbody>
</table>
<p>1235 rows × 2 columns</p>
</div>



## S&P 500 Returns

Read the S&P 500 historic closing prices and create a new daily returns DataFrame from the data. 


```python
# Reading S&P 500 Closing Prices
#Using 4.2.10 as my model here.

sp500_df = Path("Resources/sp500_history.csv")
sp500_df = pd.read_csv(
    sp500_df, index_col="Date", infer_datetime_format=True, parse_dates=True)
sp500_df = sp500_df.sort_index()
sp500_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-10-01</th>
      <td>$1444.49</td>
    </tr>
    <tr>
      <th>2012-10-02</th>
      <td>$1445.75</td>
    </tr>
    <tr>
      <th>2012-10-03</th>
      <td>$1450.99</td>
    </tr>
    <tr>
      <th>2012-10-04</th>
      <td>$1461.40</td>
    </tr>
    <tr>
      <th>2012-10-05</th>
      <td>$1460.93</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Check Data Types
sp500_df.dtypes
```




    Close    object
    dtype: object




```python
# Fix Data Types
sp500_df["Close"] = sp500_df["Close"].str.replace("$", "")
sp500_df["Close"] = sp500_df["Close"].str.replace(",", "")
sp500_df["Close"] = sp500_df["Close"].astype("float")
sp500_df.dtypes
```

    C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\ipykernel_launcher.py:2: FutureWarning: The default value of regex will change from True to False in a future version. In addition, single character regular expressions will *not* be treated as literal strings when regex=True.
      
    




    Close    float64
    dtype: object




```python
sp500_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-10-01</th>
      <td>1444.49</td>
    </tr>
    <tr>
      <th>2012-10-02</th>
      <td>1445.75</td>
    </tr>
    <tr>
      <th>2012-10-03</th>
      <td>1450.99</td>
    </tr>
    <tr>
      <th>2012-10-04</th>
      <td>1461.40</td>
    </tr>
    <tr>
      <th>2012-10-05</th>
      <td>1460.93</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>2019-04-16</th>
      <td>2907.06</td>
    </tr>
    <tr>
      <th>2019-04-17</th>
      <td>2900.45</td>
    </tr>
    <tr>
      <th>2019-04-18</th>
      <td>2905.03</td>
    </tr>
    <tr>
      <th>2019-04-22</th>
      <td>2907.97</td>
    </tr>
    <tr>
      <th>2019-04-23</th>
      <td>2933.68</td>
    </tr>
  </tbody>
</table>
<p>1649 rows × 1 columns</p>
</div>




```python
# Calculate Daily Returns
sp500_df = sp500_df.pct_change()
sp500_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-10-01</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-10-02</th>
      <td>0.000872</td>
    </tr>
    <tr>
      <th>2012-10-03</th>
      <td>0.003624</td>
    </tr>
    <tr>
      <th>2012-10-04</th>
      <td>0.007174</td>
    </tr>
    <tr>
      <th>2012-10-05</th>
      <td>-0.000322</td>
    </tr>
  </tbody>
</table>
</div>




```python
sp500_df = sp500_df.pct_change()
sp500_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-10-01</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-10-02</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-10-03</th>
      <td>3.155106</td>
    </tr>
    <tr>
      <th>2012-10-04</th>
      <td>0.979467</td>
    </tr>
    <tr>
      <th>2012-10-05</th>
      <td>-1.044827</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Drop nulls
sp500_df = sp500_df.dropna().copy()
sp500_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-10-03</th>
      <td>3.155106</td>
    </tr>
    <tr>
      <th>2012-10-04</th>
      <td>0.979467</td>
    </tr>
    <tr>
      <th>2012-10-05</th>
      <td>-1.044827</td>
    </tr>
    <tr>
      <th>2012-10-08</th>
      <td>9.748138</td>
    </tr>
    <tr>
      <th>2012-10-09</th>
      <td>1.861376</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Rename `Close` Column to be specific to this portfolio.
#Pandas.4.2 "columns" as my reference

sp500_df = sp500_df.rename(columns={
    "Date": "Date",
    "Close": "SP500",
})

sp500_df.head()                               
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SP500</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-10-03</th>
      <td>3.155106</td>
    </tr>
    <tr>
      <th>2012-10-04</th>
      <td>0.979467</td>
    </tr>
    <tr>
      <th>2012-10-05</th>
      <td>-1.044827</td>
    </tr>
    <tr>
      <th>2012-10-08</th>
      <td>9.748138</td>
    </tr>
    <tr>
      <th>2012-10-09</th>
      <td>1.861376</td>
    </tr>
  </tbody>
</table>
</div>



## Combine Whale, Algorithmic, and S&P 500 Returns


```python
# Join Whale Returns, Algorithmic Returns, and the S&P 500 Returns into a single DataFrame with columns for each portfolio's returns.
#Using 4.2.10 as my model

combined_data = pd.concat([whale_dataframe,algo_dataframe, sp500_df], axis="columns", join="inner")
combined_data

#column_appended_data = pd.concat([msft_df, sp500_df], axis="rows", join="inner")
#column_appended_data

#all_portfolios = pd.concat([whale_returns, algo_returns, sp500_returns], axis="columns", join="inner")
#all_portfolios.head()

#I cannot get the SP500_df to add to this combined data data frame.
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
      <th>Algo 1</th>
      <th>Algo 2</th>
      <th>SP500</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-03-02</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>-0.008158</td>
      <td>0.003200</td>
      <td>-3.071830</td>
    </tr>
    <tr>
      <th>2015-03-03</th>
      <td>-0.001266</td>
      <td>-0.004981</td>
      <td>-0.000496</td>
      <td>-0.006569</td>
      <td>-0.001942</td>
      <td>-0.000949</td>
      <td>-1.741001</td>
    </tr>
    <tr>
      <th>2015-03-04</th>
      <td>0.002230</td>
      <td>0.003241</td>
      <td>-0.002534</td>
      <td>0.004213</td>
      <td>-0.008589</td>
      <td>0.002416</td>
      <td>-0.033072</td>
    </tr>
    <tr>
      <th>2015-03-05</th>
      <td>0.004016</td>
      <td>0.004076</td>
      <td>0.002355</td>
      <td>0.006726</td>
      <td>-0.000955</td>
      <td>0.004323</td>
      <td>-1.272547</td>
    </tr>
    <tr>
      <th>2015-03-06</th>
      <td>-0.007905</td>
      <td>-0.003574</td>
      <td>-0.008481</td>
      <td>-0.013098</td>
      <td>-0.004957</td>
      <td>-0.011460</td>
      <td>-12.850368</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2019-04-16</th>
      <td>0.002699</td>
      <td>0.000388</td>
      <td>-0.000831</td>
      <td>0.000837</td>
      <td>-0.006945</td>
      <td>0.002899</td>
      <td>-1.809253</td>
    </tr>
    <tr>
      <th>2019-04-17</th>
      <td>-0.002897</td>
      <td>-0.006467</td>
      <td>-0.004409</td>
      <td>0.003222</td>
      <td>-0.010301</td>
      <td>-0.005228</td>
      <td>-5.463942</td>
    </tr>
    <tr>
      <th>2019-04-18</th>
      <td>0.001448</td>
      <td>0.001222</td>
      <td>0.000582</td>
      <td>0.001916</td>
      <td>-0.000588</td>
      <td>-0.001229</td>
      <td>-1.694469</td>
    </tr>
    <tr>
      <th>2019-04-22</th>
      <td>-0.002586</td>
      <td>-0.007333</td>
      <td>-0.003640</td>
      <td>-0.001088</td>
      <td>0.000677</td>
      <td>-0.001936</td>
      <td>-0.359091</td>
    </tr>
    <tr>
      <th>2019-04-23</th>
      <td>0.007167</td>
      <td>0.003485</td>
      <td>0.006472</td>
      <td>0.013278</td>
      <td>0.004969</td>
      <td>0.009622</td>
      <td>7.736057</td>
    </tr>
  </tbody>
</table>
<p>1044 rows × 7 columns</p>
</div>



---

# Conduct Quantitative Analysis

In this section, you will calculate and visualize performance and risk metrics for the portfolios.

## Performance Anlysis

#### Calculate and Plot the daily returns.


```python
# Plot daily returns of all portfolios
combined_data.plot(title = "Daily Returns")
```




    <AxesSubplot:title={'center':'Daily Returns'}, xlabel='Date'>




    
![png](output_27_1.png)
    


#### Calculate and Plot cumulative returns.


```python
# Calculate cumulative returns of all portfolios
#combined_data.cumprod() (I seem to have an error here)
#all_returns.head
combined_data.plot(figsize=(20, 10), title="Cumulative Returns")
```




    <AxesSubplot:title={'center':'Cumulative Returns'}>




    
![png](output_29_1.png)
    



```python
# Plot cumulative returns
combined_data.pct_change()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
      <th>Algo 1</th>
      <th>Algo 2</th>
      <th>SP500</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-03-02</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2015-03-03</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>-0.761929</td>
      <td>-1.296713</td>
      <td>-0.433237</td>
    </tr>
    <tr>
      <th>2015-03-04</th>
      <td>-2.762070</td>
      <td>-1.650792</td>
      <td>4.113646</td>
      <td>-1.641381</td>
      <td>3.422374</td>
      <td>-3.544766</td>
      <td>-0.981004</td>
    </tr>
    <tr>
      <th>2015-03-05</th>
      <td>0.800968</td>
      <td>0.257544</td>
      <td>-1.929234</td>
      <td>0.596558</td>
      <td>-0.888803</td>
      <td>0.789231</td>
      <td>37.477539</td>
    </tr>
    <tr>
      <th>2015-03-06</th>
      <td>-2.968465</td>
      <td>-1.876837</td>
      <td>-4.601872</td>
      <td>-2.947282</td>
      <td>4.190043</td>
      <td>-3.650914</td>
      <td>9.098145</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2019-04-16</th>
      <td>-2.898341</td>
      <td>-1.335693</td>
      <td>-3.088322</td>
      <td>-1.079744</td>
      <td>0.603391</td>
      <td>-1.634218</td>
      <td>0.651935</td>
    </tr>
    <tr>
      <th>2019-04-17</th>
      <td>-2.073108</td>
      <td>-17.661104</td>
      <td>4.306537</td>
      <td>2.851033</td>
      <td>0.483294</td>
      <td>-2.803170</td>
      <td>2.020000</td>
    </tr>
    <tr>
      <th>2019-04-18</th>
      <td>-1.499843</td>
      <td>-1.188925</td>
      <td>-1.131886</td>
      <td>-0.405345</td>
      <td>-0.942926</td>
      <td>-0.764890</td>
      <td>-0.689882</td>
    </tr>
    <tr>
      <th>2019-04-22</th>
      <td>-2.785826</td>
      <td>-7.001458</td>
      <td>-7.259521</td>
      <td>-1.567709</td>
      <td>-2.150780</td>
      <td>0.574781</td>
      <td>-0.788081</td>
    </tr>
    <tr>
      <th>2019-04-23</th>
      <td>-3.771893</td>
      <td>-1.475216</td>
      <td>-2.777848</td>
      <td>-13.206260</td>
      <td>6.345216</td>
      <td>-5.970574</td>
      <td>-22.543465</td>
    </tr>
  </tbody>
</table>
<p>1044 rows × 7 columns</p>
</div>



---

## Risk Analysis

Determine the _risk_ of each portfolio:

1. Create a box plot for each portfolio. 
2. Calculate the standard deviation for all portfolios
4. Determine which portfolios are riskier than the S&P 500
5. Calculate the Annualized Standard Deviation

### Create a box plot for each portfolio



```python
# Box plot to visually show risk
whale_dataframe.plot.box(figsize=(20,10), title="Risk")
algo_dataframe.plot.box(figsize=(20,10), title ="Risk")
sp500_df.plot.box(figsize=(20,10), title = "Risk")

```




    <AxesSubplot:title={'center':'Risk'}>




    
![png](output_34_1.png)
    



    
![png](output_34_2.png)
    



    
![png](output_34_3.png)
    


### Calculate Standard Deviations


```python
# Calculate the daily standard deviations of all portfolios
whale_dataframe.std()

```




    SOROS FUND MANAGEMENT LLC      0.007842
    PAULSON & CO.INC.              0.006977
    TIGER GLOBAL MANAGEMENT LLC    0.010824
    BERKSHIRE HATHAWAY INC         0.012831
    dtype: float64




```python
# Calculate the daily standard deviations of all portfolios
algo_dataframe.std()

```




    Algo 1    0.007988
    Algo 2    0.008466
    dtype: float64




```python
# Calculate the daily standard deviations of all portfolios
sp500_df.std()
```




    SP500   NaN
    dtype: float64




```python
combined_data.std()
```




    SOROS FUND MANAGEMENT LLC      0.007895
    PAULSON & CO.INC.              0.007023
    TIGER GLOBAL MANAGEMENT LLC    0.010894
    BERKSHIRE HATHAWAY INC         0.012919
    Algo 1                         0.007621
    Algo 2                         0.008339
    SP500                               NaN
    dtype: float64



### Determine which portfolios are riskier than the S&P 500


```python
# Calculate  the daily standard deviation of S&P 500
sp500_risk = combined_data["SP500"].std()
# Determine which portfolios are riskier than the S&P 500
combined_data.std() > sp500_risk
```




    SOROS FUND MANAGEMENT LLC      False
    PAULSON & CO.INC.              False
    TIGER GLOBAL MANAGEMENT LLC    False
    BERKSHIRE HATHAWAY INC         False
    Algo 1                         False
    Algo 2                         False
    SP500                          False
    dtype: bool



### Calculate the Annualized Standard Deviation


```python
# Calculate the annualized standard deviation (252 trading days)
annualized_deviation_df = combined_data.std() * np.sqrt(252)
annualized_deviation_df


```




    SOROS FUND MANAGEMENT LLC      0.125335
    PAULSON & CO.INC.              0.111488
    TIGER GLOBAL MANAGEMENT LLC    0.172936
    BERKSHIRE HATHAWAY INC         0.205077
    Algo 1                         0.120987
    Algo 2                         0.132374
    SP500                               NaN
    dtype: float64



---

## Rolling Statistics

Risk changes over time. Analyze the rolling statistics for Risk and Beta. 

1. Calculate and plot the rolling standard deviation for all portfolios using a 21-day window
2. Calculate the correlation between each stock to determine which portfolios may mimick the S&P 500
3. Choose one portfolio, then calculate and plot the 60-day rolling beta between it and the S&P 500

### Calculate and plot rolling `std` for all portfolios with 21-day window


```python
# Calculate the rolling standard deviation for all portfolios using a 21-day window
combined_data.plot.box(figsize=(20, 10), title="Standard Deviation")
# Plot the rolling standard deviation

```




    <AxesSubplot:title={'center':'Standard Deviation'}>




    
![png](output_47_1.png)
    


### Calculate and plot the correlation


```python
# Calculate the correlation
corr_df = combined_data.corr()
corr_df
# Display de correlation matrix
corr_df.style.background_gradient(cmap="Accent")
```




<style type="text/css">
#T_7aadc_row0_col0, #T_7aadc_row1_col1, #T_7aadc_row2_col2, #T_7aadc_row3_col3, #T_7aadc_row4_col4, #T_7aadc_row5_col5, #T_7aadc_row6_col6 {
  background-color: #666666;
  color: #f1f1f1;
}
#T_7aadc_row0_col1, #T_7aadc_row1_col0, #T_7aadc_row1_col5, #T_7aadc_row3_col5, #T_7aadc_row5_col1, #T_7aadc_row5_col3 {
  background-color: #f0027f;
  color: #f1f1f1;
}
#T_7aadc_row0_col2, #T_7aadc_row1_col3, #T_7aadc_row2_col0, #T_7aadc_row2_col5, #T_7aadc_row3_col1, #T_7aadc_row5_col2 {
  background-color: #386cb0;
  color: #f1f1f1;
}
#T_7aadc_row0_col3, #T_7aadc_row0_col5, #T_7aadc_row3_col0, #T_7aadc_row5_col0 {
  background-color: #bf5b17;
  color: #f1f1f1;
}
#T_7aadc_row0_col4, #T_7aadc_row1_col4, #T_7aadc_row3_col4, #T_7aadc_row4_col0, #T_7aadc_row4_col1, #T_7aadc_row4_col3, #T_7aadc_row4_col5, #T_7aadc_row5_col4 {
  background-color: #fdc086;
  color: #000000;
}
#T_7aadc_row0_col6, #T_7aadc_row1_col6, #T_7aadc_row2_col6, #T_7aadc_row3_col6, #T_7aadc_row4_col6, #T_7aadc_row5_col6, #T_7aadc_row6_col0, #T_7aadc_row6_col1, #T_7aadc_row6_col2, #T_7aadc_row6_col3, #T_7aadc_row6_col4, #T_7aadc_row6_col5 {
  background-color: #7fc97f;
  color: #000000;
}
#T_7aadc_row1_col2, #T_7aadc_row2_col1, #T_7aadc_row2_col3, #T_7aadc_row3_col2 {
  background-color: #ffff99;
  color: #000000;
}
#T_7aadc_row2_col4, #T_7aadc_row4_col2 {
  background-color: #beaed4;
  color: #000000;
}
</style>
<table id="T_7aadc_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >SOROS FUND MANAGEMENT LLC</th>
      <th class="col_heading level0 col1" >PAULSON & CO.INC. </th>
      <th class="col_heading level0 col2" >TIGER GLOBAL MANAGEMENT LLC</th>
      <th class="col_heading level0 col3" >BERKSHIRE HATHAWAY INC</th>
      <th class="col_heading level0 col4" >Algo 1</th>
      <th class="col_heading level0 col5" >Algo 2</th>
      <th class="col_heading level0 col6" >SP500</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_7aadc_level0_row0" class="row_heading level0 row0" >SOROS FUND MANAGEMENT LLC</th>
      <td id="T_7aadc_row0_col0" class="data row0 col0" >1.000000</td>
      <td id="T_7aadc_row0_col1" class="data row0 col1" >0.699914</td>
      <td id="T_7aadc_row0_col2" class="data row0 col2" >0.561243</td>
      <td id="T_7aadc_row0_col3" class="data row0 col3" >0.754360</td>
      <td id="T_7aadc_row0_col4" class="data row0 col4" >0.321211</td>
      <td id="T_7aadc_row0_col5" class="data row0 col5" >0.826873</td>
      <td id="T_7aadc_row0_col6" class="data row0 col6" >-0.014070</td>
    </tr>
    <tr>
      <th id="T_7aadc_level0_row1" class="row_heading level0 row1" >PAULSON & CO.INC. </th>
      <td id="T_7aadc_row1_col0" class="data row1 col0" >0.699914</td>
      <td id="T_7aadc_row1_col1" class="data row1 col1" >1.000000</td>
      <td id="T_7aadc_row1_col2" class="data row1 col2" >0.434479</td>
      <td id="T_7aadc_row1_col3" class="data row1 col3" >0.545623</td>
      <td id="T_7aadc_row1_col4" class="data row1 col4" >0.268840</td>
      <td id="T_7aadc_row1_col5" class="data row1 col5" >0.678152</td>
      <td id="T_7aadc_row1_col6" class="data row1 col6" >-0.009986</td>
    </tr>
    <tr>
      <th id="T_7aadc_level0_row2" class="row_heading level0 row2" >TIGER GLOBAL MANAGEMENT LLC</th>
      <td id="T_7aadc_row2_col0" class="data row2 col0" >0.561243</td>
      <td id="T_7aadc_row2_col1" class="data row2 col1" >0.434479</td>
      <td id="T_7aadc_row2_col2" class="data row2 col2" >1.000000</td>
      <td id="T_7aadc_row2_col3" class="data row2 col3" >0.424423</td>
      <td id="T_7aadc_row2_col4" class="data row2 col4" >0.164387</td>
      <td id="T_7aadc_row2_col5" class="data row2 col5" >0.507414</td>
      <td id="T_7aadc_row2_col6" class="data row2 col6" >-0.007296</td>
    </tr>
    <tr>
      <th id="T_7aadc_level0_row3" class="row_heading level0 row3" >BERKSHIRE HATHAWAY INC</th>
      <td id="T_7aadc_row3_col0" class="data row3 col0" >0.754360</td>
      <td id="T_7aadc_row3_col1" class="data row3 col1" >0.545623</td>
      <td id="T_7aadc_row3_col2" class="data row3 col2" >0.424423</td>
      <td id="T_7aadc_row3_col3" class="data row3 col3" >1.000000</td>
      <td id="T_7aadc_row3_col4" class="data row3 col4" >0.292033</td>
      <td id="T_7aadc_row3_col5" class="data row3 col5" >0.688082</td>
      <td id="T_7aadc_row3_col6" class="data row3 col6" >-0.010328</td>
    </tr>
    <tr>
      <th id="T_7aadc_level0_row4" class="row_heading level0 row4" >Algo 1</th>
      <td id="T_7aadc_row4_col0" class="data row4 col0" >0.321211</td>
      <td id="T_7aadc_row4_col1" class="data row4 col1" >0.268840</td>
      <td id="T_7aadc_row4_col2" class="data row4 col2" >0.164387</td>
      <td id="T_7aadc_row4_col3" class="data row4 col3" >0.292033</td>
      <td id="T_7aadc_row4_col4" class="data row4 col4" >1.000000</td>
      <td id="T_7aadc_row4_col5" class="data row4 col5" >0.287650</td>
      <td id="T_7aadc_row4_col6" class="data row4 col6" >-0.033061</td>
    </tr>
    <tr>
      <th id="T_7aadc_level0_row5" class="row_heading level0 row5" >Algo 2</th>
      <td id="T_7aadc_row5_col0" class="data row5 col0" >0.826873</td>
      <td id="T_7aadc_row5_col1" class="data row5 col1" >0.678152</td>
      <td id="T_7aadc_row5_col2" class="data row5 col2" >0.507414</td>
      <td id="T_7aadc_row5_col3" class="data row5 col3" >0.688082</td>
      <td id="T_7aadc_row5_col4" class="data row5 col4" >0.287650</td>
      <td id="T_7aadc_row5_col5" class="data row5 col5" >1.000000</td>
      <td id="T_7aadc_row5_col6" class="data row5 col6" >-0.043585</td>
    </tr>
    <tr>
      <th id="T_7aadc_level0_row6" class="row_heading level0 row6" >SP500</th>
      <td id="T_7aadc_row6_col0" class="data row6 col0" >-0.014070</td>
      <td id="T_7aadc_row6_col1" class="data row6 col1" >-0.009986</td>
      <td id="T_7aadc_row6_col2" class="data row6 col2" >-0.007296</td>
      <td id="T_7aadc_row6_col3" class="data row6 col3" >-0.010328</td>
      <td id="T_7aadc_row6_col4" class="data row6 col4" >-0.033061</td>
      <td id="T_7aadc_row6_col5" class="data row6 col5" >-0.043585</td>
      <td id="T_7aadc_row6_col6" class="data row6 col6" >1.000000</td>
    </tr>
  </tbody>
</table>




### Calculate and Plot Beta for a chosen portfolio and the S&P 500


```python
# Calculate covariance of a single portfolio

# Calculate variance of S&P 500

# Computing beta

# Plot beta trend

```

## Rolling Statistics Challenge: Exponentially Weighted Average 

An alternative way to calculate a rolling window is to take the exponentially weighted moving average. This is like a moving window average, but it assigns greater importance to more recent observations. Try calculating the [`ewm`](https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.ewm.html) with a 21-day half-life.


```python
# Use `ewm` to calculate the rolling window
combined_data.ewm(halflife=21).std().plot(figsize=(20, 10), title="Exponentially Weighted Average")
```




    <AxesSubplot:title={'center':'Exponentially Weighted Average'}, xlabel='Date'>




    
![png](output_53_1.png)
    



```python
combined_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
      <th>Algo 1</th>
      <th>Algo 2</th>
      <th>SP500</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-03-02</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>-0.008158</td>
      <td>0.003200</td>
      <td>-3.071830</td>
    </tr>
    <tr>
      <th>2015-03-03</th>
      <td>-0.001266</td>
      <td>-0.004981</td>
      <td>-0.000496</td>
      <td>-0.006569</td>
      <td>-0.001942</td>
      <td>-0.000949</td>
      <td>-1.741001</td>
    </tr>
    <tr>
      <th>2015-03-04</th>
      <td>0.002230</td>
      <td>0.003241</td>
      <td>-0.002534</td>
      <td>0.004213</td>
      <td>-0.008589</td>
      <td>0.002416</td>
      <td>-0.033072</td>
    </tr>
    <tr>
      <th>2015-03-05</th>
      <td>0.004016</td>
      <td>0.004076</td>
      <td>0.002355</td>
      <td>0.006726</td>
      <td>-0.000955</td>
      <td>0.004323</td>
      <td>-1.272547</td>
    </tr>
    <tr>
      <th>2015-03-06</th>
      <td>-0.007905</td>
      <td>-0.003574</td>
      <td>-0.008481</td>
      <td>-0.013098</td>
      <td>-0.004957</td>
      <td>-0.011460</td>
      <td>-12.850368</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2019-04-16</th>
      <td>0.002699</td>
      <td>0.000388</td>
      <td>-0.000831</td>
      <td>0.000837</td>
      <td>-0.006945</td>
      <td>0.002899</td>
      <td>-1.809253</td>
    </tr>
    <tr>
      <th>2019-04-17</th>
      <td>-0.002897</td>
      <td>-0.006467</td>
      <td>-0.004409</td>
      <td>0.003222</td>
      <td>-0.010301</td>
      <td>-0.005228</td>
      <td>-5.463942</td>
    </tr>
    <tr>
      <th>2019-04-18</th>
      <td>0.001448</td>
      <td>0.001222</td>
      <td>0.000582</td>
      <td>0.001916</td>
      <td>-0.000588</td>
      <td>-0.001229</td>
      <td>-1.694469</td>
    </tr>
    <tr>
      <th>2019-04-22</th>
      <td>-0.002586</td>
      <td>-0.007333</td>
      <td>-0.003640</td>
      <td>-0.001088</td>
      <td>0.000677</td>
      <td>-0.001936</td>
      <td>-0.359091</td>
    </tr>
    <tr>
      <th>2019-04-23</th>
      <td>0.007167</td>
      <td>0.003485</td>
      <td>0.006472</td>
      <td>0.013278</td>
      <td>0.004969</td>
      <td>0.009622</td>
      <td>7.736057</td>
    </tr>
  </tbody>
</table>
<p>1044 rows × 7 columns</p>
</div>



---

# Sharpe Ratios
In reality, investment managers and thier institutional investors look at the ratio of return-to-risk, and not just returns alone. After all, if you could invest in one of two portfolios, and each offered the same 10% return, yet one offered lower risk, you'd take that one, right?

### Using the daily returns, calculate and visualize the Sharpe ratios using a bar plot


```python
# Annualized Sharpe Ratios
sharpe_ratios = (combined_data.mean() * 252) / (combined_data.std() * np.sqrt(252))
sharpe_ratios
```




    SOROS FUND MANAGEMENT LLC      0.356417
    PAULSON & CO.INC.             -0.483570
    TIGER GLOBAL MANAGEMENT LLC   -0.121060
    BERKSHIRE HATHAWAY INC         0.621810
    Algo 1                         1.360829
    Algo 2                         0.506929
    SP500                               NaN
    dtype: float64




```python
# Visualize the sharpe ratios as a bar plot
sharpe_ratios.plot(kind="bar", title="Sharpe Ratios")
```




    <AxesSubplot:title={'center':'Sharpe Ratios'}>




    
![png](output_58_1.png)
    


### Determine whether the algorithmic strategies outperform both the market (S&P 500) and the whales portfolios.

Write your answer here!

---

# Create Custom Portfolio

In this section, you will build your own portfolio of stocks, calculate the returns, and compare the results to the Whale Portfolios and the S&P 500. 

1. Choose 3-5 custom stocks with at last 1 year's worth of historic prices and create a DataFrame of the closing prices and dates for each stock.
2. Calculate the weighted returns for the portfolio assuming an equal number of shares for each stock
3. Join your portfolio returns to the DataFrame that contains all of the portfolio returns
4. Re-run the performance and risk analysis with your portfolio to see how it compares to the others
5. Include correlation analysis to determine which stocks (if any) are correlated

## Choose 3-5 custom stocks with at last 1 year's worth of historic prices and create a DataFrame of the closing prices and dates for each stock.


```python
# Reading data from 1st stock
ford_path = Path("Resources/Ford.csv")
ford_path
```




    WindowsPath('Resources/Ford.csv')




```python
ford_df = pd.read_csv(ford_path)
ford_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6/1/2021 16:00</td>
      <td>14.81</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6/2/2021 16:00</td>
      <td>14.91</td>
    </tr>
    <tr>
      <th>2</th>
      <td>6/3/2021 16:00</td>
      <td>15.99</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6/4/2021 16:00</td>
      <td>15.97</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6/7/2021 16:00</td>
      <td>15.88</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Reading data from 2nd stock
toyota_path = Path("Resources/Toyota.csv")
toyota_path
```




    WindowsPath('Resources/Toyota.csv')




```python
toyota_df = pd.read_csv(toyota_path)
toyota_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6/1/2021 16:00</td>
      <td>172.34</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6/2/2021 16:00</td>
      <td>176.63</td>
    </tr>
    <tr>
      <th>2</th>
      <td>6/3/2021 16:00</td>
      <td>179.67</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6/4/2021 16:00</td>
      <td>182.41</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6/7/2021 16:00</td>
      <td>180.80</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Reading data from 3rd stock
gm_path = Path("Resources/GM.csv")
gm_path
```




    WindowsPath('Resources/GM.csv')




```python
gm_df = pd.read_csv(gm_path)
gm_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6/1/2021 16:00</td>
      <td>59.65</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6/2/2021 16:00</td>
      <td>59.65</td>
    </tr>
    <tr>
      <th>2</th>
      <td>6/3/2021 16:00</td>
      <td>63.46</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6/4/2021 16:00</td>
      <td>63.37</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6/7/2021 16:00</td>
      <td>63.23</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Combine all stocks in a single DataFrame
new_combined_data = pd.concat([toyota_df, ford_df, gm_df], axis="columns", join="inner")
new_combined_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Close</th>
      <th>Date</th>
      <th>Close</th>
      <th>Date</th>
      <th>Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6/1/2021 16:00</td>
      <td>172.34</td>
      <td>6/1/2021 16:00</td>
      <td>14.81</td>
      <td>6/1/2021 16:00</td>
      <td>59.65</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6/2/2021 16:00</td>
      <td>176.63</td>
      <td>6/2/2021 16:00</td>
      <td>14.91</td>
      <td>6/2/2021 16:00</td>
      <td>59.65</td>
    </tr>
    <tr>
      <th>2</th>
      <td>6/3/2021 16:00</td>
      <td>179.67</td>
      <td>6/3/2021 16:00</td>
      <td>15.99</td>
      <td>6/3/2021 16:00</td>
      <td>63.46</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6/4/2021 16:00</td>
      <td>182.41</td>
      <td>6/4/2021 16:00</td>
      <td>15.97</td>
      <td>6/4/2021 16:00</td>
      <td>63.37</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6/7/2021 16:00</td>
      <td>180.80</td>
      <td>6/7/2021 16:00</td>
      <td>15.88</td>
      <td>6/7/2021 16:00</td>
      <td>63.23</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>145</th>
      <td>12/27/2021 16:00</td>
      <td>185.90</td>
      <td>12/27/2021 16:00</td>
      <td>20.80</td>
      <td>12/27/2021 16:00</td>
      <td>57.43</td>
    </tr>
    <tr>
      <th>146</th>
      <td>12/28/2021 16:00</td>
      <td>184.75</td>
      <td>12/28/2021 16:00</td>
      <td>20.76</td>
      <td>12/28/2021 16:00</td>
      <td>57.11</td>
    </tr>
    <tr>
      <th>147</th>
      <td>12/29/2021 16:00</td>
      <td>183.68</td>
      <td>12/29/2021 16:00</td>
      <td>20.56</td>
      <td>12/29/2021 16:00</td>
      <td>57.23</td>
    </tr>
    <tr>
      <th>148</th>
      <td>12/30/2021 16:00</td>
      <td>184.08</td>
      <td>12/30/2021 16:00</td>
      <td>20.47</td>
      <td>12/30/2021 16:00</td>
      <td>58.13</td>
    </tr>
    <tr>
      <th>149</th>
      <td>12/31/2021 16:00</td>
      <td>185.30</td>
      <td>12/31/2021 16:00</td>
      <td>20.77</td>
      <td>12/31/2021 16:00</td>
      <td>58.63</td>
    </tr>
  </tbody>
</table>
<p>150 rows × 6 columns</p>
</div>




```python
# Reset Date index
new_combined_data = new_combined_data.reset_index()
new_combined_data.head()
#add 1 date for index
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>Date</th>
      <th>Close</th>
      <th>Date</th>
      <th>Close</th>
      <th>Date</th>
      <th>Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>6/1/2021 16:00</td>
      <td>172.34</td>
      <td>6/1/2021 16:00</td>
      <td>14.81</td>
      <td>6/1/2021 16:00</td>
      <td>59.65</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>6/2/2021 16:00</td>
      <td>176.63</td>
      <td>6/2/2021 16:00</td>
      <td>14.91</td>
      <td>6/2/2021 16:00</td>
      <td>59.65</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>6/3/2021 16:00</td>
      <td>179.67</td>
      <td>6/3/2021 16:00</td>
      <td>15.99</td>
      <td>6/3/2021 16:00</td>
      <td>63.46</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>6/4/2021 16:00</td>
      <td>182.41</td>
      <td>6/4/2021 16:00</td>
      <td>15.97</td>
      <td>6/4/2021 16:00</td>
      <td>63.37</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>6/7/2021 16:00</td>
      <td>180.80</td>
      <td>6/7/2021 16:00</td>
      <td>15.88</td>
      <td>6/7/2021 16:00</td>
      <td>63.23</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Reorganize portfolio data by having a column per symbol
new_combined_data.drop(columns=['Date','index'], inplace=True)
new_combined_data

#rename column headers
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
      <th>Close</th>
      <th>Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>172.34</td>
      <td>14.81</td>
      <td>59.65</td>
    </tr>
    <tr>
      <th>1</th>
      <td>176.63</td>
      <td>14.91</td>
      <td>59.65</td>
    </tr>
    <tr>
      <th>2</th>
      <td>179.67</td>
      <td>15.99</td>
      <td>63.46</td>
    </tr>
    <tr>
      <th>3</th>
      <td>182.41</td>
      <td>15.97</td>
      <td>63.37</td>
    </tr>
    <tr>
      <th>4</th>
      <td>180.80</td>
      <td>15.88</td>
      <td>63.23</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>145</th>
      <td>185.90</td>
      <td>20.80</td>
      <td>57.43</td>
    </tr>
    <tr>
      <th>146</th>
      <td>184.75</td>
      <td>20.76</td>
      <td>57.11</td>
    </tr>
    <tr>
      <th>147</th>
      <td>183.68</td>
      <td>20.56</td>
      <td>57.23</td>
    </tr>
    <tr>
      <th>148</th>
      <td>184.08</td>
      <td>20.47</td>
      <td>58.13</td>
    </tr>
    <tr>
      <th>149</th>
      <td>185.30</td>
      <td>20.77</td>
      <td>58.63</td>
    </tr>
  </tbody>
</table>
<p>150 rows × 3 columns</p>
</div>




```python
# Calculate daily returns
daily_returns = new_combined_data.pct_change()
daily_returns.head()
# Drop NAs
daily_returns = daily_returns.dropna()

# Display sample data
daily_returns.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
      <th>Close</th>
      <th>Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>0.024893</td>
      <td>0.006752</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.017211</td>
      <td>0.072435</td>
      <td>0.063873</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.015250</td>
      <td>-0.001251</td>
      <td>-0.001418</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.008826</td>
      <td>-0.005636</td>
      <td>-0.002209</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-0.006582</td>
      <td>-0.015743</td>
      <td>0.010913</td>
    </tr>
  </tbody>
</table>
</div>



## Calculate the weighted returns for the portfolio assuming an equal number of shares for each stock


```python
# Set weights
weights = [1/3, 1/3, 1/3]

# Calculate portfolio return
weighted_returns = daily_returns.dot(weights)

# Display sample data
weighted_returns.head()
```




    1    0.010548
    2    0.051173
    3    0.004194
    4   -0.005557
    5   -0.003804
    dtype: float64



## Join your portfolio returns to the DataFrame that contains all of the portfolio returns


```python
# Join your returns DataFrame to the original returns DataFrame
combined_data["Custom"] = weighted_returns
combined_data.tail()

#add dates
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SOROS FUND MANAGEMENT LLC</th>
      <th>PAULSON &amp; CO.INC.</th>
      <th>TIGER GLOBAL MANAGEMENT LLC</th>
      <th>BERKSHIRE HATHAWAY INC</th>
      <th>Algo 1</th>
      <th>Algo 2</th>
      <th>SP500</th>
      <th>Custom</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-04-16</th>
      <td>0.002699</td>
      <td>0.000388</td>
      <td>-0.000831</td>
      <td>0.000837</td>
      <td>-0.006945</td>
      <td>0.002899</td>
      <td>-1.809253</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2019-04-17</th>
      <td>-0.002897</td>
      <td>-0.006467</td>
      <td>-0.004409</td>
      <td>0.003222</td>
      <td>-0.010301</td>
      <td>-0.005228</td>
      <td>-5.463942</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2019-04-18</th>
      <td>0.001448</td>
      <td>0.001222</td>
      <td>0.000582</td>
      <td>0.001916</td>
      <td>-0.000588</td>
      <td>-0.001229</td>
      <td>-1.694469</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2019-04-22</th>
      <td>-0.002586</td>
      <td>-0.007333</td>
      <td>-0.003640</td>
      <td>-0.001088</td>
      <td>0.000677</td>
      <td>-0.001936</td>
      <td>-0.359091</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2019-04-23</th>
      <td>0.007167</td>
      <td>0.003485</td>
      <td>0.006472</td>
      <td>0.013278</td>
      <td>0.004969</td>
      <td>0.009622</td>
      <td>7.736057</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Only compare dates where return data exists for all the stocks (drop NaNs)
combined_data = combined_data.dropna().copy()
```

## Re-run the risk analysis with your portfolio to see how it compares to the others

### Calculate the Annualized Standard Deviation


```python
# Calculate the annualized `std`
risk_analysis = combined_data.std() * np.sqrt(252)
risk_analysis
```




    SOROS FUND MANAGEMENT LLC     NaN
    PAULSON & CO.INC.             NaN
    TIGER GLOBAL MANAGEMENT LLC   NaN
    BERKSHIRE HATHAWAY INC        NaN
    Algo 1                        NaN
    Algo 2                        NaN
    SP500                         NaN
    Custom                        NaN
    dtype: float64



### Calculate and plot rolling `std` with 21-day window


```python
# Calculate rolling standard deviation
rolling_std = combined_data.rolling(window=21).std()
# Plot rolling standard deviation
rolling_std.plot(figsize=(20, 10), title="21 Day Rolling Standard Deviation")
```




    <AxesSubplot:title={'center':'21 Day Rolling Standard Deviation'}, xlabel='Date'>




    
![png](output_82_1.png)
    


### Calculate and plot the correlation


```python
# Calculate and plot the correlation
df = combined_data.corr()
df.style.background_gradient(cmap="bwr")
```

    C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\pandas\io\formats\style.py:2813: RuntimeWarning: All-NaN slice encountered
      smin = np.nanmin(gmap) if vmin is None else vmin
    C:\Users\13212\Anaconda3\envs\pyvizenv\lib\site-packages\pandas\io\formats\style.py:2814: RuntimeWarning: All-NaN slice encountered
      smax = np.nanmax(gmap) if vmax is None else vmax
    




<style type="text/css">
#T_2f761_row0_col0, #T_2f761_row0_col1, #T_2f761_row0_col2, #T_2f761_row0_col3, #T_2f761_row0_col4, #T_2f761_row0_col5, #T_2f761_row0_col6, #T_2f761_row0_col7, #T_2f761_row1_col0, #T_2f761_row1_col1, #T_2f761_row1_col2, #T_2f761_row1_col3, #T_2f761_row1_col4, #T_2f761_row1_col5, #T_2f761_row1_col6, #T_2f761_row1_col7, #T_2f761_row2_col0, #T_2f761_row2_col1, #T_2f761_row2_col2, #T_2f761_row2_col3, #T_2f761_row2_col4, #T_2f761_row2_col5, #T_2f761_row2_col6, #T_2f761_row2_col7, #T_2f761_row3_col0, #T_2f761_row3_col1, #T_2f761_row3_col2, #T_2f761_row3_col3, #T_2f761_row3_col4, #T_2f761_row3_col5, #T_2f761_row3_col6, #T_2f761_row3_col7, #T_2f761_row4_col0, #T_2f761_row4_col1, #T_2f761_row4_col2, #T_2f761_row4_col3, #T_2f761_row4_col4, #T_2f761_row4_col5, #T_2f761_row4_col6, #T_2f761_row4_col7, #T_2f761_row5_col0, #T_2f761_row5_col1, #T_2f761_row5_col2, #T_2f761_row5_col3, #T_2f761_row5_col4, #T_2f761_row5_col5, #T_2f761_row5_col6, #T_2f761_row5_col7, #T_2f761_row6_col0, #T_2f761_row6_col1, #T_2f761_row6_col2, #T_2f761_row6_col3, #T_2f761_row6_col4, #T_2f761_row6_col5, #T_2f761_row6_col6, #T_2f761_row6_col7, #T_2f761_row7_col0, #T_2f761_row7_col1, #T_2f761_row7_col2, #T_2f761_row7_col3, #T_2f761_row7_col4, #T_2f761_row7_col5, #T_2f761_row7_col6, #T_2f761_row7_col7 {
  background-color: #000000;
  color: #f1f1f1;
}
</style>
<table id="T_2f761_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >SOROS FUND MANAGEMENT LLC</th>
      <th class="col_heading level0 col1" >PAULSON & CO.INC. </th>
      <th class="col_heading level0 col2" >TIGER GLOBAL MANAGEMENT LLC</th>
      <th class="col_heading level0 col3" >BERKSHIRE HATHAWAY INC</th>
      <th class="col_heading level0 col4" >Algo 1</th>
      <th class="col_heading level0 col5" >Algo 2</th>
      <th class="col_heading level0 col6" >SP500</th>
      <th class="col_heading level0 col7" >Custom</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_2f761_level0_row0" class="row_heading level0 row0" >SOROS FUND MANAGEMENT LLC</th>
      <td id="T_2f761_row0_col0" class="data row0 col0" >nan</td>
      <td id="T_2f761_row0_col1" class="data row0 col1" >nan</td>
      <td id="T_2f761_row0_col2" class="data row0 col2" >nan</td>
      <td id="T_2f761_row0_col3" class="data row0 col3" >nan</td>
      <td id="T_2f761_row0_col4" class="data row0 col4" >nan</td>
      <td id="T_2f761_row0_col5" class="data row0 col5" >nan</td>
      <td id="T_2f761_row0_col6" class="data row0 col6" >nan</td>
      <td id="T_2f761_row0_col7" class="data row0 col7" >nan</td>
    </tr>
    <tr>
      <th id="T_2f761_level0_row1" class="row_heading level0 row1" >PAULSON & CO.INC. </th>
      <td id="T_2f761_row1_col0" class="data row1 col0" >nan</td>
      <td id="T_2f761_row1_col1" class="data row1 col1" >nan</td>
      <td id="T_2f761_row1_col2" class="data row1 col2" >nan</td>
      <td id="T_2f761_row1_col3" class="data row1 col3" >nan</td>
      <td id="T_2f761_row1_col4" class="data row1 col4" >nan</td>
      <td id="T_2f761_row1_col5" class="data row1 col5" >nan</td>
      <td id="T_2f761_row1_col6" class="data row1 col6" >nan</td>
      <td id="T_2f761_row1_col7" class="data row1 col7" >nan</td>
    </tr>
    <tr>
      <th id="T_2f761_level0_row2" class="row_heading level0 row2" >TIGER GLOBAL MANAGEMENT LLC</th>
      <td id="T_2f761_row2_col0" class="data row2 col0" >nan</td>
      <td id="T_2f761_row2_col1" class="data row2 col1" >nan</td>
      <td id="T_2f761_row2_col2" class="data row2 col2" >nan</td>
      <td id="T_2f761_row2_col3" class="data row2 col3" >nan</td>
      <td id="T_2f761_row2_col4" class="data row2 col4" >nan</td>
      <td id="T_2f761_row2_col5" class="data row2 col5" >nan</td>
      <td id="T_2f761_row2_col6" class="data row2 col6" >nan</td>
      <td id="T_2f761_row2_col7" class="data row2 col7" >nan</td>
    </tr>
    <tr>
      <th id="T_2f761_level0_row3" class="row_heading level0 row3" >BERKSHIRE HATHAWAY INC</th>
      <td id="T_2f761_row3_col0" class="data row3 col0" >nan</td>
      <td id="T_2f761_row3_col1" class="data row3 col1" >nan</td>
      <td id="T_2f761_row3_col2" class="data row3 col2" >nan</td>
      <td id="T_2f761_row3_col3" class="data row3 col3" >nan</td>
      <td id="T_2f761_row3_col4" class="data row3 col4" >nan</td>
      <td id="T_2f761_row3_col5" class="data row3 col5" >nan</td>
      <td id="T_2f761_row3_col6" class="data row3 col6" >nan</td>
      <td id="T_2f761_row3_col7" class="data row3 col7" >nan</td>
    </tr>
    <tr>
      <th id="T_2f761_level0_row4" class="row_heading level0 row4" >Algo 1</th>
      <td id="T_2f761_row4_col0" class="data row4 col0" >nan</td>
      <td id="T_2f761_row4_col1" class="data row4 col1" >nan</td>
      <td id="T_2f761_row4_col2" class="data row4 col2" >nan</td>
      <td id="T_2f761_row4_col3" class="data row4 col3" >nan</td>
      <td id="T_2f761_row4_col4" class="data row4 col4" >nan</td>
      <td id="T_2f761_row4_col5" class="data row4 col5" >nan</td>
      <td id="T_2f761_row4_col6" class="data row4 col6" >nan</td>
      <td id="T_2f761_row4_col7" class="data row4 col7" >nan</td>
    </tr>
    <tr>
      <th id="T_2f761_level0_row5" class="row_heading level0 row5" >Algo 2</th>
      <td id="T_2f761_row5_col0" class="data row5 col0" >nan</td>
      <td id="T_2f761_row5_col1" class="data row5 col1" >nan</td>
      <td id="T_2f761_row5_col2" class="data row5 col2" >nan</td>
      <td id="T_2f761_row5_col3" class="data row5 col3" >nan</td>
      <td id="T_2f761_row5_col4" class="data row5 col4" >nan</td>
      <td id="T_2f761_row5_col5" class="data row5 col5" >nan</td>
      <td id="T_2f761_row5_col6" class="data row5 col6" >nan</td>
      <td id="T_2f761_row5_col7" class="data row5 col7" >nan</td>
    </tr>
    <tr>
      <th id="T_2f761_level0_row6" class="row_heading level0 row6" >SP500</th>
      <td id="T_2f761_row6_col0" class="data row6 col0" >nan</td>
      <td id="T_2f761_row6_col1" class="data row6 col1" >nan</td>
      <td id="T_2f761_row6_col2" class="data row6 col2" >nan</td>
      <td id="T_2f761_row6_col3" class="data row6 col3" >nan</td>
      <td id="T_2f761_row6_col4" class="data row6 col4" >nan</td>
      <td id="T_2f761_row6_col5" class="data row6 col5" >nan</td>
      <td id="T_2f761_row6_col6" class="data row6 col6" >nan</td>
      <td id="T_2f761_row6_col7" class="data row6 col7" >nan</td>
    </tr>
    <tr>
      <th id="T_2f761_level0_row7" class="row_heading level0 row7" >Custom</th>
      <td id="T_2f761_row7_col0" class="data row7 col0" >nan</td>
      <td id="T_2f761_row7_col1" class="data row7 col1" >nan</td>
      <td id="T_2f761_row7_col2" class="data row7 col2" >nan</td>
      <td id="T_2f761_row7_col3" class="data row7 col3" >nan</td>
      <td id="T_2f761_row7_col4" class="data row7 col4" >nan</td>
      <td id="T_2f761_row7_col5" class="data row7 col5" >nan</td>
      <td id="T_2f761_row7_col6" class="data row7 col6" >nan</td>
      <td id="T_2f761_row7_col7" class="data row7 col7" >nan</td>
    </tr>
  </tbody>
</table>




### Calculate and Plot Rolling 60-day Beta for Your Portfolio compared to the S&P 500


```python
# Calculate and plot Beta
covariance = combined_portfolios["Custom"].rolling(window=60).cov(all_portfolios["S&P 500"])
variance = combined_portfolios["S&P 500"].rolling(60).var()
beta = (covariance / variance)
beta.plot(figsize=(20, 10), title="Custom Portfolio Beta")
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    ~\AppData\Local\Temp/ipykernel_20740/2546826728.py in <module>
          1 # Calculate and plot Beta
    ----> 2 covariance = combined_portfolios["Custom"].rolling(window=60).cov(all_portfolios["S&P 500"])
          3 variance = combined_portfolios["S&P 500"].rolling(60).var()
          4 beta = (covariance / variance)
          5 beta.plot(figsize=(20, 10), title="Custom Portfolio Beta")
    

    NameError: name 'combined_portfolios' is not defined


### Using the daily returns, calculate and visualize the Sharpe ratios using a bar plot


```python
# Calculate Annualized Sharpe Ratios
sharpe_ratios = (combined_portfolios.mean() * 252) / (combined_portfolios.std() * np.sqrt(252))
sharpe_ratios
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    ~\AppData\Local\Temp/ipykernel_20740/2655100332.py in <module>
          1 # Calculate Annualized Sharpe Ratios
    ----> 2 sharpe_ratios = (combined_portfolios.mean() * 252) / (combined_portfolios.std() * np.sqrt(252))
          3 sharpe_ratios
    

    NameError: name 'combined_portfolios' is not defined



```python
# Visualize the sharpe ratios as a bar plot
sharpe_ratios.plot(kind="bar", title="Sharpe Ratios")
```




    <AxesSubplot:title={'center':'Sharpe Ratios'}>




    
![png](output_89_1.png)
    


### How does your portfolio do?

Write your answer here!


```python

```
